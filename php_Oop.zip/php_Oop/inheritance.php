<?php
class Animal
{
     public $name ;

    function __construct($name)
    {
        $this->name = $name ;

    }

    function sleep()
    {
        echo "{$this->name} can sleep\n";
    }

    function greeting()
    {
        echo "{$this->name} say greetingmew2\n" ;
    }

    function sayhi()
    {
        echo " hi\n";
    }

    function eat()
    {
        echo "{$this->name} can eat rice\n";
    }

    function run()
    {
        echo "{$this->name} can run\n";
    }

}

class cat extends Animal{
   
    
    
    function greeting()
    {
        parent::greeting();
        echo "{$this->name} say mew2\n" ;
    }
    function sayhi()
    {
        echo " hi\n";
    }

}
 class human extends Animal{

 }

$fahima= new Animal('fahima');
$fahima->eat();
$fahima->sayhi();
$rita= new human("fah");
 $rita->run();

$cat1=new cat('mimi');
$cat1->greeting();
$cat1->run();