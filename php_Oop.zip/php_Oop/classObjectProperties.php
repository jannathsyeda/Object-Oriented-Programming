<?php
Class Human{
    function sayhi()
    {
        $name;
        echo "hi";
    }
}
$hi = new Human();
$hi->name="fahima";
$hi->sayhi();
echo $hi->name;